from pymongo import MongoClient

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        USER = 'aacuser'
        PASS = 'aacuser01'
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        uri = f"mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}?authSource={DB}"
        self.client = MongoClient(uri)

        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        if data:
            return self.collection.insert_one(data).acknowledged
        return False

    def read(self, query=None):
        if query:
            return list(self.collection.find(query))
        else:
            return list(self.collection.find({}))

    def update(self, query, new_values):
        if query and new_values:
            result = self.collection.update_many(query, {'$set': new_values})
            return result.modified_count
        return 0

    def delete(self, query):
        if query:
            result = self.collection.delete_many(query)
            return result.deleted_count
        return 0
    
if __name__ == "__main__":
    shelter = AnimalShelter()
    print(shelter.database.list_collection_names())

if __name__ == "__main__":
    shelter = AnimalShelter()

    # Test create
    new_animal = {
        "name": "Buddy",
        "breed": "Golden Retriever",
        "age": 3,
        "adopted": False
    }
    shelter.create(new_animal)
    print("Inserted new animal.")

    # Test read
    results = shelter.read({"name": "Buddy"})
    for animal in results:
        print(animal)
    
    # Test update
    updated_count = shelter.update({"name": "Buddy"}, {"adopted": True})
    print(f"Updated {updated_count} Buddy record(s).")

    # Verify update
    results = shelter.read({"name": "Buddy"})
    for animal in results:
        print(animal)

    # Delete test entries
    deleted_count = shelter.delete({"name": "Buddy"})
    print(f"Deleted {deleted_count} test entries.")
